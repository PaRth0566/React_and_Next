"use client";

import { useState } from "react";

const students = [
  // STUdent 1
  {
    studentId: "40721240034",
    name: "Parth Rathod",
    rollNo: "090",
    program: "BSc. CS",
    exams: [
      // s1
      {
        sem: 1,
        subject: "C programming",
        icaMarks: 8,
        eseMarks: 55,
      },
      // s2
      {
        sem: 2,
        subject: "CN",
        icaMarks: 28,
        eseMarks: 20,
      },
      // s3
      {
        sem: 3,
        subject: "DBMS",
        icaMarks: 16,
        eseMarks: 24,
      },
      // s4
      {
        sem: 4,
        subject: ".Net",
        icaMarks: 22,
        eseMarks: 55,
      },
      {
        sem: 4,
        subject: "PHP",
        icaMarks: 18,
        eseMarks: 45,
      },
      {
        sem: 4,
        subject: "Flutter",
        icaMarks: 25,
        eseMarks: 35,
      },
      {
        sem: 4,
        subject: "Next.js",
        icaMarks: 8,
        eseMarks: 55,
      },
    ],
  },

  // Student 2
  {
    studentId: "40721240033",
    name: "Hardik Rathod",
    rollNo: "089",
    program: "BSc. CS",
    exams: [
      //s5
      {
        sem: 5,
        subject: "R",
        icaMarks: 23,
        eseMarks: 45,
      },
      {
        sem: 5,
        subject: "Rust",
        icaMarks: 15,
        eseMarks: 55,
      },
      {
        sem: 5,
        subject: "C++",
        icaMarks: 18,
        eseMarks: 49,
      },
    ],
  },
];

function getGrade(total) {
  if (total >= 80) return { grade: "O", point: 10 };
  if (total >= 60) return { grade: "A", point: 8 };
  if (total >= 50) return { grade: "B", point: 6 };
  if (total >= 45) return { grade: "C", point: 5 };
  if (total > 40) return { grade: "P", point: 4 };

  return { grade: "F", point: 0 };
}

export default function Page() {
  const [selectedStudent, setSelectedStudent] = useState("");
  const [selectedSem, setSelectedSem] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  // To get the student array
  const student = students.find(
    (student) => student.studentId === selectedStudent,
  );

  // To get the semester for that student
  const semesters = student
    ? [...new Set(student.exams.map((exam) => exam.sem))].sort()
    : [];

  // To handle the Show result button
  function handleShowResult() {
    if (!student) {
      setError("Please select a student");
      setResult(null);
      return;
    }

    if (!selectedSem) {
      setError("Please select a semester");
      setResult(null);
      return;
    }

    // Find subjects for the respective student and semester
    const subjects = student.exams
      .filter((exam) => exam.sem === Number(selectedSem))
      .map((exam) => {
        const total = exam.icaMarks + exam.eseMarks;

        const icaPassed = exam.icaMarks > 16;
        const esePassed = exam.eseMarks > 24;
        const totalPassed = total > 40;

        const passed = icaPassed && esePassed && totalPassed;

        const { grade, point } = getGrade(total);

        return {
          ...exam,
          total,
          passed,
          grade: passed ? grade : "F",
          gradePoint: passed ? point : 0,
        };
      });

    if (subjects.length === 0) {
      setError("No exam data found for this semester");
      setResult(null);
      return;
    }

    const totalMarks = subjects.reduce(
      (sum, subject) => sum + subject.total,
      0,
    );

    const maxMarks = subjects.length * 100;

    const percentage = ((totalMarks / maxMarks) * 100).toFixed(2);

    const sgpa = (
      subjects.reduce(
        (sum, subject) => sum + subject.gradePoint,
        0,
      ) / subjects.length
    ).toFixed(2);

    const allPassed = subjects.every(
      (subject) => subject.passed,
    );

    setError("");

    setResult({
      subjects,
      totalMarks,
      maxMarks,
      percentage,
      sgpa,
      allPassed,
    });
  }

  return (
    <main>
      <h1>Student Result</h1>

      <br />

      <label>Student: </label>

      <select
        value={selectedStudent}
        onChange={(e) => {
          setSelectedStudent(e.target.value);
          setSelectedSem("");
          setResult(null);
          setError("");
        }}
      >
        <option value="">Select Student</option>

        {students.map((student) => (
          <option
            key={student.studentId}
            value={student.studentId}
          >
            {student.name}
          </option>
        ))}
      </select>

      <br />

      <label>Semester: </label>

      <select
        value={selectedSem}
        onChange={(e) => {
          setSelectedSem(e.target.value);
          setResult(null);
          setError("");
        }}
      >
        <option value="">Select Semester</option>

        {semesters.map((sem) => (
          <option key={sem} value={sem}>
            Semester {sem}
          </option>
        ))}
      </select>

      {" "}

      <button onClick={handleShowResult}>
        Show Result
      </button>

      {error && <p>{error}</p>}

      {result && (
        <section>
          <h2>Marksheet - Semester {selectedSem}</h2>

          <p>
            Student ID: {student.studentId}
            <br />
            Name: {student.name}
            <br />
            Roll No: {student.rollNo}
            <br />
            Program: {student.program}
          </p>

          <table
            style={{
              borderCollapse: "collapse",
              width: "100%",
            }}
          >
            <thead>
              <tr>
                <th
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                  }}
                >
                  Subject
                </th>

                <th
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                  }}
                >
                  ICA
                </th>

                <th
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                  }}
                >
                  ESE
                </th>

                <th
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                  }}
                >
                  Total
                </th>

                <th
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                  }}
                >
                  Grade
                </th>

                <th
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                  }}
                >
                  Status
                </th>
              </tr>
            </thead>

            <tbody>
              {result.subjects.map((subject) => (
                <tr key={subject.subject}>
                  <td
                    style={{
                      border: "1px solid black",
                      padding: "8px",
                    }}
                  >
                    {subject.subject}
                  </td>

                  <td
                    style={{
                      border: "1px solid black",
                      padding: "8px",
                    }}
                  >
                    {subject.icaMarks}
                  </td>

                  <td
                    style={{
                      border: "1px solid black",
                      padding: "8px",
                    }}
                  >
                    {subject.eseMarks}
                  </td>

                  <td
                    style={{
                      border: "1px solid black",
                      padding: "8px",
                    }}
                  >
                    {subject.total}
                  </td>

                  <td
                    style={{
                      border: "1px solid black",
                      padding: "8px",
                    }}
                  >
                    {subject.grade}
                  </td>

                  <td
                    style={{
                      border: "1px solid black",
                      padding: "8px",
                    }}
                  >
                    {subject.passed ? "Pass" : "Fail"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <p>
            Total: {result.totalMarks}/{result.maxMarks}
            <br />
            Percentage: {result.percentage}%
            <br />
            SGPA: {result.sgpa}
            <br />
            Result:{" "}
            {result.allPassed ? "PASSED" : "FAILED"}
          </p>
        </section>
      )}
    </main>
  );
}